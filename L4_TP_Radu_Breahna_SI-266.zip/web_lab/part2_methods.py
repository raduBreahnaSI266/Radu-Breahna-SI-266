# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

response = requests.get(BASE_URL, timeout=TIMEOUT)

# ---------------------------------------------------------------- Ex. 9
print("Ex9")
print(response.status_code)  # atribut
print(response.ok)           # atribut (proprietate)
print(response.url)          # atribut
print(response.encoding)     # atribut

# ---------------------------------------------------------------- Ex. 10
print("Ex10")
response.raise_for_status()  # metodă; nu face nimic dacă totul e în regulă
time.sleep(1)
try:
    r404 = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    r404.raise_for_status()
except requests.HTTPError as e:
    print("Pagina cerută nu există sau serverul a răspuns cu eroare:", e)

# ---------------------------------------------------------------- Ex. 11
print("Ex11")
for name, value in response.headers.items():
    print(f"{name}: {value}")

# ---------------------------------------------------------------- Ex. 12
print("Ex12")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type (litere mici):", response.headers.get("content-type", "lipsește"))
# Observație: se obține aceeași valoare, deoarece response.headers este un
# dicționar insensibil la majuscule (CaseInsensitiveDict).

# ---------------------------------------------------------------- Ex. 13
print("Ex13")
print("cyber apare de", response.text.lower().count("cyber"), "ori")
# .lower() returnează un șir nou (str), iar .count() este o metodă a oricărui
# str, deci rezultatul lui .lower() poate primi direct un apel .count().

# ---------------------------------------------------------------- Ex. 14
print("Ex14")
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print("Titlu:", html[start:end].strip())

# ---------------------------------------------------------------- Ex. 15
print("Ex15")
lines = html.splitlines()
print("Număr de linii:", len(lines))
if lines:
    print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))

# ---------------------------------------------------------------- Ex. 16
print("Ex16")
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

# ---------------------------------------------------------------- Ex. 17
print("Ex17")
time.sleep(1)
r = requests.get("http://cybercor.org", timeout=TIMEOUT)
for step in r.history:
    print(step.status_code, step.url)
print("URL final:", r.url)

# ---------------------------------------------------------------- Ex. 18
print("Ex18")
time.sleep(1)
r_head = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
r_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD:", len(r_head.content), "octeți; GET:", len(r_get.content), "octeți")
# HEAD cere doar antetele, serverul nu trimite corpul, deci len(content) este 0.
# GET returnează și corpul paginii (HTML-ul).

# ---------------------------------------------------------------- Ex. 19
print("Ex19")
if len(response.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in response.cookies:
        print(cookie.name, cookie.secure)

# ---------------------------------------------------------------- Ex. 20
print("Ex20")
time.sleep(1)
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Nume-Prenume"})
r = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(r.text)
print("User-Agent trimis:", r.json()["headers"].get("User-Agent"))

# Verificați-vă: response.text este un ATRIBUT (o valoare deja calculată/proprietate),
# iar response.json() este o METODĂ (o acțiune care face parsarea JSON la apel),
# de aceea se apelează cu paranteze.
