# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
import argparse
import csv
import time
from datetime import datetime

import webtools                                  # Ex. 44
from webtools import get_title, security_headers  # Ex. 45
from webtools import DEFAULT_HEADERS              # Ex. 47

# Ex. 45: dacă main.py ar avea propria funcție get_title, definiția ei ar
# înlocui (ar "umbri") get_title importată din webtools, deoarece ultimul nume
# atribuit câștigă; apelurile ar folosi funcția locală, nu cea din webtools.

BASE_URL = "https://cybercor.org"


def write_csv(results, path="report.csv"):
    """Ex. 49: salvează {cale: status} în CSV cu coloanele path, status, checked_at."""
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "status", "checked_at"])
        for p, status in results.items():
            writer.writerow([p, status, datetime.now().isoformat()])


def main():
    # Ex. 48: URL-ul vine din linia de comandă
    parser = argparse.ArgumentParser(description="Raport despre un site web.")
    parser.add_argument("url", nargs="?", default=BASE_URL,
                        help="adresa site-ului, ex. https://cybercor.org")
    args = parser.parse_args()
    url = args.url.rstrip("/")

    # Ex. 44 / 45 / 47
    print("Titlu:", get_title(webtools.fetch(url).text))
    time.sleep(1)
    print("Antete de securitate:", security_headers(url))
    print("Antete implicite:", DEFAULT_HEADERS)
    time.sleep(1)

    # Ex. 49
    results = webtools.check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    write_csv(results)
    print("Salvat în report.csv")
    time.sleep(1)

    # Ex. 50
    webtools.site_report(url)


if __name__ == "__main__":
    main()
