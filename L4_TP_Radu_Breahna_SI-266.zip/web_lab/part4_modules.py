# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
import hashlib
import json
import re
import socket
import ssl
import time
import urllib.parse
from datetime import datetime
from html.parser import HTMLParser

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# ---------------------------------------------------------------- Ex. 35
def show_url_parts(url: str):
    """Afișează părțile unui URL (scheme, netloc, path, query, fragment)."""
    p = urllib.parse.urlparse(url)
    print("scheme:", p.scheme)
    print("netloc:", p.netloc)
    print("path:", p.path)
    print("query:", p.query)
    print("fragment:", p.fragment)


# ---------------------------------------------------------------- Ex. 36
def join_links(base: str, links: list) -> list:
    """Transformă legăturile relative în URL-uri complete, pornind de la base."""
    return [urllib.parse.urljoin(base, link) for link in links]


# ---------------------------------------------------------------- Ex. 37
def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate (păstrează ordinea)."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


# ---------------------------------------------------------------- Ex. 38
def split_links(links: list, domain: str):
    """Returnează (interne, externe): legături de pe același domeniu și de pe alte site-uri."""
    internal, external = [], []
    for link in links:
        full = urllib.parse.urljoin("https://" + domain, link)
        parsed = urllib.parse.urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue  # ignorăm mailto:, javascript: etc.
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


# ---------------------------------------------------------------- Ex. 39
class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":  # HTMLParser transformă deja numele tag-ului în litere mici
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


# ---------------------------------------------------------------- Ex. 40
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a conținutului paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


# ---------------------------------------------------------------- Ex. 42
def resolve(hostname: str) -> str:
    """Returnează adresa IP (IPv4) a unui nume de domeniu."""
    return socket.gethostbyname(hostname)


# ---------------------------------------------------------------- Ex. 43
def cert_days_left(hostname: str) -> int:
    """Returnează numărul de zile rămase până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    expires = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expires - time.time()) // 86400)


if __name__ == "__main__":
    # Ex. 35
    print("Ex35")
    show_url_parts("https://cybercor.org/path?x=1#top")

    # Ex. 36
    print("Ex36")
    for url in join_links(BASE_URL, ["/about", "contact.html", "../index.html"]):
        print(url)

    # Ex. 37 + 38
    print("Ex37/38")
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    html = response.text
    links = extract_links(html)
    print(len(links), "legături unice")
    internal, external = split_links(links, "cybercor.org")
    print(len(internal), "interne,", len(external), "externe")

    # Ex. 39: testul pe HTML cunoscut vine primul
    print("Ex39")
    test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fără src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == [
        "/logo.png",                            # imagine obișnuită
        "poza.jpg",                             # tag scris cu majuscule
        "https://cdn.example.com/banner.webp",  # tag care se închide singur
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    # Apoi pe pagina reală (refolosim răspunsul deja descărcat, fără cerere nouă)
    finder = ImageFinder()
    finder.feed(html)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Verificare: count('<img') =", html.lower().count("<img"))

    # Ex. 40
    print("Ex40")
    h1 = page_fingerprint(BASE_URL)
    time.sleep(1)
    h2 = page_fingerprint(BASE_URL)
    print(h1)
    print(h2)
    print("Identice:", h1 == h2)
    # Ar fi diferite dacă pagina s-a schimbat între cereri (conținut dinamic:
    # dată/oră, token CSRF, reclame, recomandări) sau dacă serverul a trimis alt conținut.

    # Ex. 41
    print("Ex41")
    with open("headers.json", "w", encoding="utf-8") as f:
        json.dump(dict(response.headers), f, indent=2)
    with open("headers.json", encoding="utf-8") as f:
        loaded = json.load(f)
    first_key = next(iter(loaded), None)
    if first_key:
        print(first_key, "=", loaded[first_key])

    # Ex. 42
    print("Ex42:", resolve("cybercor.org"))

    # Ex. 43
    print("Ex43:", cert_days_left("cybercor.org"), "zile rămase")

    # Verificați-vă: handle_starttag() este apelată de parser (de metoda feed()),
    # nu de noi; este un "callback": noi definim ce se întâmplă, iar HTMLParser
    # decide când se apelează, la fiecare tag de deschidere întâlnit.
