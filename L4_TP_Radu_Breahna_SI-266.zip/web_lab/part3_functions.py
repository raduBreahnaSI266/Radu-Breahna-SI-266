# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# ---------------------------------------------------------------- Ex. 21 + 23
def fetch(url, timeout=10):
    """Descarcă url cu GET și returnează obiectul răspuns (Ex. 21, parametru implicit Ex. 23)."""
    return requests.get(url, timeout=timeout)


# ---------------------------------------------------------------- Ex. 22 + 26
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


# ---------------------------------------------------------------- Ex. 24 + 25
def get_title(html: str) -> str:
    """Returnează titlul paginii (textul dintre <title> și </title>) sau un șir gol.

    Funcția nu face operații de rețea: primește doar codul HTML.
    """
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()


# ---------------------------------------------------------------- Ex. 27
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu succes, altfel False (fără excepții)."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False


# ---------------------------------------------------------------- Ex. 28
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale din listă."""
    results = {}
    for i, path in enumerate(paths):
        if i > 0:
            time.sleep(1)
        try:
            results[path] = get_status(base + path)
        except requests.RequestException:
            results[path] = None
    return results


# ---------------------------------------------------------------- Ex. 29
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name din răspunsul de la url sau default."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)


# ---------------------------------------------------------------- Ex. 30
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    response = requests.get(url, timeout=TIMEOUT)
    return {name: name in response.headers for name in SECURITY_HEADERS}


# ---------------------------------------------------------------- Ex. 31
def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează un șir precum '3/5'."""
    return f"{sum(results.values())}/{len(results)}"


# ---------------------------------------------------------------- Ex. 32
def fetch_robots(base: str):
    """Returnează textul din /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow: din robots.txt (listă goală pentru None)."""
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


# ---------------------------------------------------------------- Ex. 33
def response_times(*urls) -> dict:
    """Returnează {url: secunde} cu durata fiecărei cereri."""
    times = {}
    for i, url in enumerate(urls):
        if i > 0:
            time.sleep(1)
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        times[url] = round(time.perf_counter() - start, 3)
    return times


# ---------------------------------------------------------------- Ex. 34
def log(message, **details):
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [str(message)] + [f"{k}={v}" for k, v in details.items()]
    print(" | ".join(parts))


if __name__ == "__main__":
    # Ex. 21
    print("Ex21:", fetch(BASE_URL).status_code)
    time.sleep(1)

    # Ex. 22
    for p in ["/", "/robots.txt", "/sitemap.xml"]:
        print("Ex22:", p, get_status(BASE_URL + p))
        time.sleep(1)

    # Ex. 23
    print("Ex23 (implicit):", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("Ex23 (timeout=3):", fetch(BASE_URL, timeout=3).status_code)
    time.sleep(1)

    # Ex. 24
    print("Ex24:", get_title(fetch(BASE_URL).text))
    time.sleep(1)

    # Ex. 25
    help(get_title)

    # Ex. 26: adnotările de tip NU opresc execuția; Python nu le verifică.
    # Eroarea apare din requests (URL invalid), nu din adnotare.
    try:
        get_status(123)
    except Exception as e:
        print("Ex26: get_status(123) a dat", type(e).__name__, "- adnotarea nu a oprit apelul")

    # Ex. 27
    print("Ex27:", page_exists(BASE_URL))
    time.sleep(1)
    print("Ex27:", page_exists("https://this-domain-does-not-exist.invalid"))
    time.sleep(1)

    # Ex. 28
    print("Ex28:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))
    time.sleep(1)

    # Ex. 29
    print("Ex29:", get_header(BASE_URL, name="Server"))
    time.sleep(1)

    # Ex. 30 + 31
    sec = security_headers(BASE_URL)
    print("Ex30:", sec)
    print("Ex31:", score_headers(sec))
    time.sleep(1)

    # Ex. 32
    robots = fetch_robots(BASE_URL)
    print("Ex32:", disallowed_paths(robots))
    print("Ex32 (None):", disallowed_paths(None))
    time.sleep(1)

    # Ex. 33
    print("Ex33:", response_times(BASE_URL, BASE_URL + "/robots.txt"))

    # Ex. 34
    log("verificat", url=BASE_URL, status=200)

    # Verificați-vă: print() doar AFIȘEAZĂ o valoare pe ecran și funcția
    # returnează None; return trimite valoarea înapoi apelantului, care o poate
    # stoca, procesa sau trimite mai departe altei funcții.
