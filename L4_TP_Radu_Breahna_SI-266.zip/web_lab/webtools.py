# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
"""webtools: funcții reutilizabile pentru analiza unui site web."""
import json
import re
import socket
import ssl
import time
import urllib.parse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Ex. 47: constantă de modul
DEFAULT_HEADERS = {"User-Agent": "WebLab-Nume-Prenume"}

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def fetch(url, timeout=TIMEOUT):
    """Descarcă url cu GET (cu User-Agent personalizat) și returnează răspunsul."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html):
    """Returnează titlul paginii (între <title> și </title>) sau un șir gol."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()


def security_headers(url):
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADERS}


def score_headers(results):
    """Primește rezultatul security_headers și returnează un scor precum '3/5'."""
    return f"{sum(results.values())}/{len(results)}"


def check_paths(base, paths):
    """Returnează {cale: cod_de_stare} pentru fiecare cale (None dacă cererea eșuează)."""
    results = {}
    for i, path in enumerate(paths):
        if i > 0:
            time.sleep(1)
        try:
            results[path] = get_status(base + path)
        except requests.RequestException:
            results[path] = None
    return results


def fetch_robots(base):
    """Returnează textul din /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    return response.text if response.status_code == 200 else None


def disallowed_paths(robots_text):
    """Returnează lista valorilor Disallow: (listă goală dacă robots_text este None)."""
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


def extract_links(html):
    """Returnează legăturile href din html, fără duplicate, în ordinea din pagină."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links, domain):
    """Returnează (interne, externe) în funcție de domeniul legăturii."""
    internal, external = [], []
    for link in links:
        full = urllib.parse.urljoin("https://" + domain, link)
        parsed = urllib.parse.urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        (internal if parsed.netloc == domain else external).append(full)
    return internal, external


def resolve(hostname):
    """Returnează adresa IP a unui nume de domeniu."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname):
    """Returnează zilele rămase până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            cert = tls.getpeercert()
    return int((ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) // 86400)


def redirect_chain(url):
    """Returnează lista redirecționărilor pornind de la varianta http:// a lui url."""
    host = urllib.parse.urlparse(url).netloc
    response = fetch("http://" + host)
    chain = [f"{step.status_code} -> {step.headers.get('Location', '?')}"
             for step in response.history]
    return chain, response.url


def site_report(url, output="report.json"):
    """Colectează informații despre site, le afișează și le salvează în report.json."""
    host = urllib.parse.urlparse(url).netloc
    report = {"url": url}

    response = fetch(url)
    report["status"] = response.status_code
    report["final_url"] = response.url
    time.sleep(1)

    report["title"] = get_title(response.text)
    report["ip"] = resolve(host)

    try:
        report["redirects"], _final = redirect_chain(url)
    except requests.RequestException:
        report["redirects"] = []
    time.sleep(1)

    try:
        report["security_score"] = score_headers(security_headers(url))
    except requests.RequestException:
        report["security_score"] = "n/a"
    time.sleep(1)

    try:
        report["cert_days_left"] = cert_days_left(host)
    except (OSError, ssl.SSLError, KeyError):
        report["cert_days_left"] = None

    internal, external = split_links(extract_links(response.text), host)
    report["links_internal"] = len(internal)
    report["links_external"] = len(external)
    time.sleep(1)

    report["disallowed"] = disallowed_paths(fetch_robots(url))

    redirects = ", ".join(report["redirects"]) or "niciuna"
    cert = report["cert_days_left"]
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare: {report['status']}")
    print(f"Titlu: {report['title']}")
    print(f"Adresă IP: {report['ip']}")
    print(f"Redirecționări: {redirects}")
    print(f"Scor securitate: {report['security_score']}")
    print("Certificat:", f"{cert} de zile rămase" if cert is not None else "indisponibil")
    print(f"Legături: {report['links_internal']} interne, {report['links_external']} externe")
    print(f"Căi interzise: {', '.join(report['disallowed']) or 'niciuna'}")

    with open(output, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"Salvat în {output}")
    return report


if __name__ == "__main__":
    # Ex. 46: rulează doar când fișierul este pornit direct (python webtools.py).
    # La "import webtools" variabila __name__ este "webtools", nu "__main__",
    # deci blocul este ignorat.
    print("Autotest:", get_status("https://cybercor.org"))
