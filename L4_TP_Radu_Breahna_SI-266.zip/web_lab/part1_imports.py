# Laborator: funcții, metode și importuri pe web
# Student: <Nume Prenume>
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

# ---------------------------------------------------------------- Ex. 1
import requests
print("Ex1: versiunea requests =", requests.__version__)
import urllib.request
# requests este o bibliotecă externă (scrisă de terți), care nu vine cu Python,
# deci trebuie descărcată cu pip install requests. urllib face parte din
# biblioteca standard, adică este instalată odată cu Python.

# ---------------------------------------------------------------- Ex. 2
# Stilul 1: import requests
r = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex2 (import requests):", r.status_code)
time.sleep(1)

# Stilul 2: from requests import get
from requests import get
r = get(BASE_URL, timeout=TIMEOUT)
print("Ex2 (from requests import get):", r.status_code)
time.sleep(1)
# Avantaj "import requests": se vede mereu de unde vine funcția (requests.get),
# deci nu apar confuzii de nume.
# Avantaj "from requests import get": codul este mai scurt, fără prefix.

# ---------------------------------------------------------------- Ex. 3
import requests as rq
r = rq.get(BASE_URL, timeout=TIMEOUT)
print("Ex3 (alias rq):", r.status_code)
time.sleep(1)
# Un alias ajută când numele este lung și se repetă mult, iar aliasul este
# unul consacrat (import numpy as np). Îl face mai greu de citit când este
# inventat și criptic (rq, x), pentru că cititorul trebuie să ghicească ce e.

# ---------------------------------------------------------------- Ex. 4
resp = urllib.request.urlopen(BASE_URL, timeout=TIMEOUT)
print("Ex4: status =", resp.status)
body = resp.read().decode("utf-8")  # .read() dă bytes; .decode() dă str
print(body[:200])
time.sleep(1)

# ---------------------------------------------------------------- Ex. 5
print("Ex5:", dir(requests))
# Exemple de nume din dir(requests):
#   get       -> funcție
#   Session   -> clasă
#   exceptions-> modul (submodul al pachetului requests)

# ---------------------------------------------------------------- Ex. 6
help(requests.get)
# Parametrul pentru timpul maxim de așteptare este "timeout" (vine prin **kwargs
# în requests.get, descris în requests.request).
r = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex6: cerere cu timeout =", TIMEOUT, "->", r.status_code)
time.sleep(1)

# ---------------------------------------------------------------- Ex. 7
start = time.perf_counter()
r = requests.get(BASE_URL, timeout=TIMEOUT)
durata = time.perf_counter() - start
print(f"Ex7: perf_counter = {durata:.3f} s, response.elapsed = "
      f"{r.elapsed.total_seconds():.3f} s")
# perf_counter măsoară tot timpul din programul vostru (inclusiv citirea corpului);
# elapsed măsoară doar timpul până la primirea antetelor răspunsului.
time.sleep(1)

# ---------------------------------------------------------------- Ex. 8
try:
    import bs4
    print("Ex8: bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificați-vă:
# - modul = un singur fișier .py care se poate importa;
# - pachet = director cu mai multe module (are __init__.py);
# - bibliotecă = termen general pentru o colecție de cod reutilizabil
#   (poate fi un modul sau un pachet).
